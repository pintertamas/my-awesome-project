#ifndef MY_AWESOME_PROJECT_SETTINGS_H
#define MY_AWESOME_PROJECT_SETTINGS_H

#include "global.h"

Color settingsBackground;

void settings ();
void initGameData();

#endif //MY_AWESOME_PROJECT_SETTINGS_H
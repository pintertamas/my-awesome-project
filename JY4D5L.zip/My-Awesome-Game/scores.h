#ifndef MY_AWESOME_PROJECT_SCORES_H
#define MY_AWESOME_PROJECT_SCORES_H

int score_time;
int scoreArray[10][3];
void readFromFile (int array[10][3]);
void writeToFile (int array[10][3]);
void endOfGame ();
void scores();

#endif //MY_AWESOME_PROJECT_SCORES_H
#include "global.h"
#include "debugmalloc.h"

int resolutionX = 1920;
int resolutionY = 1080;

int screenWidth = 600;
int screenHeight = 900;

int menu_screenWidth = 900;
int menu_screenHeight = 600;

Color BACKGROUND_COLOR = {0,210,255};